import json
import math
import os
import time
import urllib.error
import urllib.request
from typing import Any

try:
    import MetaTrader5 as mt5
except ImportError as error:  # pragma: no cover - runtime script
    raise SystemExit(
        "MetaTrader5 package is required. Install it with: pip install -r bridge/requirements.txt"
    ) from error


POLL_INTERVAL_SECONDS = float(os.environ.get("COINEXX_BRIDGE_POLL_INTERVAL", "1.5"))
WORKER_BASE_URL = os.environ.get("WORKER_BASE_URL", "").rstrip("/")
BRIDGE_TOKEN = os.environ.get("COINEXX_BRIDGE_TOKEN", "")
MT5_LOGIN = os.environ.get("MT5_LOGIN", "")
MT5_PASSWORD = os.environ.get("MT5_PASSWORD", "")
MT5_SERVER = os.environ.get("MT5_SERVER", "")
MT5_TERMINAL_PATH = os.environ.get("MT5_TERMINAL_PATH", "")
GOLD_SYMBOL = os.environ.get("COINEXX_GOLD_SYMBOL", "XAUUSD")
MAGIC_NUMBER = int(os.environ.get("COINEXX_BRIDGE_MAGIC", "20260512"))


def main() -> int:
    validate_config()
    print(f"Coinexx MT5 bridge started. Worker: {WORKER_BASE_URL} Symbol: {GOLD_SYMBOL}")

    while True:
        connected, last_error = ensure_mt5_connection()
        heartbeat = build_heartbeat_snapshot(connected, last_error)

        try:
            poll_response = post_json("/bridge/poll", heartbeat)
        except Exception as error:  # pragma: no cover - runtime path
            print(f"[poll] request failed: {error}")
            time.sleep(POLL_INTERVAL_SECONDS)
            continue

        job = poll_response.get("job")
        if job:
            result = execute_job(job, connected, last_error)
            try:
                post_json("/bridge/report", result)
            except Exception as error:  # pragma: no cover - runtime path
                print(f"[report] request failed: {error}")

        time.sleep(POLL_INTERVAL_SECONDS)


def validate_config() -> None:
    missing = []
    if not WORKER_BASE_URL:
        missing.append("WORKER_BASE_URL")
    if not BRIDGE_TOKEN:
        missing.append("COINEXX_BRIDGE_TOKEN")
    if not MT5_LOGIN:
        missing.append("MT5_LOGIN")
    if not MT5_PASSWORD:
        missing.append("MT5_PASSWORD")
    if not MT5_SERVER:
        missing.append("MT5_SERVER")

    if missing:
        raise SystemExit(f"Missing required env vars: {', '.join(missing)}")


def ensure_mt5_connection() -> tuple[bool, str | None]:
    initialized = mt5.initialize(path=MT5_TERMINAL_PATH or None)
    if not initialized:
        return False, f"initialize failed: {mt5.last_error()}"

    authorized = mt5.login(int(MT5_LOGIN), password=MT5_PASSWORD, server=MT5_SERVER)
    if not authorized:
        return False, f"login failed: {mt5.last_error()}"

    return True, None


def build_heartbeat_snapshot(connected: bool, last_error: str | None) -> dict[str, Any]:
    account = mt5.account_info() if connected else None
    positions = mt5.positions_get(symbol=GOLD_SYMBOL) if connected else None
    gold_position = positions[0] if positions else None

    direction = None
    volume = None
    if gold_position:
        direction = "BUY" if gold_position.type == mt5.POSITION_TYPE_BUY else "SELL"
        volume = float(gold_position.volume)

    return {
        "login": MT5_LOGIN,
        "server": MT5_SERVER,
        "balance": float(account.balance) if account else None,
        "equity": float(account.equity) if account else None,
        "free_margin": float(account.margin_free) if account else None,
        "connected": connected,
        "gold_position_open": gold_position is not None,
        "gold_position_direction": direction,
        "gold_position_volume": volume,
        "last_error": last_error,
    }


def execute_job(job: dict[str, Any], connected: bool, last_error: str | None) -> dict[str, Any]:
    job_id = int(job["id"])

    if not connected:
        return {
            "job_id": job_id,
            "status": "failed",
            "error_message": last_error or "MT5 bridge is not connected."
        }

    if has_open_gold_position():
        return {
            "job_id": job_id,
            "status": "rejected",
            "error_message": f"{GOLD_SYMBOL} position is already open."
        }

    order_type = mt5.ORDER_TYPE_BUY if job["direction"] == "BUY" else mt5.ORDER_TYPE_SELL
    symbol_info = mt5.symbol_info(GOLD_SYMBOL)
    if symbol_info is None:
        return {
            "job_id": job_id,
            "status": "failed",
            "error_message": f"Symbol {GOLD_SYMBOL} is not available in MT5."
        }

    if not symbol_info.visible and not mt5.symbol_select(GOLD_SYMBOL, True):
        return {
            "job_id": job_id,
            "status": "failed",
            "error_message": f"Could not select symbol {GOLD_SYMBOL}."
        }

    tick = mt5.symbol_info_tick(GOLD_SYMBOL)
    if tick is None:
        return {
            "job_id": job_id,
            "status": "failed",
            "error_message": f"Could not read live tick for {GOLD_SYMBOL}."
        }

    price = float(tick.ask if order_type == mt5.ORDER_TYPE_BUY else tick.bid)
    account = mt5.account_info()
    if account is None:
        return {
            "job_id": job_id,
            "status": "failed",
            "error_message": "Could not read account info from MT5."
        }

    target_margin = float(account.balance) * float(job["requested_margin_percent"]) / 100.0
    volume = find_volume_for_margin(order_type, GOLD_SYMBOL, price, target_margin)
    if volume is None:
        return {
            "job_id": job_id,
            "status": "rejected",
            "error_message": "Requested margin allocation is below the broker minimum lot."
        }

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": GOLD_SYMBOL,
        "volume": volume,
        "type": order_type,
        "price": price,
        "sl": float(job["sl"]),
        "tp": float(job["tp"]),
        "deviation": 20,
        "magic": MAGIC_NUMBER,
        "comment": f"codex-bridge job={job_id}",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": int(getattr(symbol_info, "filling_mode", mt5.ORDER_FILLING_IOC) or mt5.ORDER_FILLING_IOC),
    }

    result = mt5.order_send(request)
    if result is None:
        return {
            "job_id": job_id,
            "status": "failed",
            "error_message": f"order_send returned None: {mt5.last_error()}"
        }

    retcode_done = getattr(mt5, "TRADE_RETCODE_DONE", 10009)
    if result.retcode != retcode_done:
        return {
            "job_id": job_id,
            "status": "rejected",
            "order_ticket": getattr(result, "order", None),
            "error_message": f"retcode={result.retcode} comment={getattr(result, 'comment', '')}".strip()
        }

    return {
        "job_id": job_id,
        "status": "filled",
        "order_ticket": getattr(result, "order", None),
        "fill_price": price
    }


def has_open_gold_position() -> bool:
    positions = mt5.positions_get(symbol=GOLD_SYMBOL)
    return bool(positions)


def find_volume_for_margin(order_type: int, symbol: str, price: float, target_margin: float) -> float | None:
    symbol_info = mt5.symbol_info(symbol)
    if symbol_info is None:
        return None

    volume_min = float(symbol_info.volume_min)
    volume_max = float(symbol_info.volume_max)
    volume_step = float(symbol_info.volume_step)

    if target_margin <= 0 or volume_min <= 0 or volume_step <= 0:
        return None

    low = volume_min
    high = volume_max
    best = None

    for _ in range(40):
        midpoint = math.floor(((low + high) / 2.0) / volume_step) * volume_step
        midpoint = max(volume_min, min(volume_max, round(midpoint, 8)))

        margin = mt5.order_calc_margin(order_type, symbol, midpoint, price)
        if margin is None:
            break

        if margin <= target_margin:
            best = midpoint
            low = midpoint + volume_step
        else:
            high = midpoint - volume_step

    if best is None:
        margin_at_min = mt5.order_calc_margin(order_type, symbol, volume_min, price)
        if margin_at_min is not None and margin_at_min <= target_margin:
            best = volume_min

    if best is None or best < volume_min:
        return None

    return round(math.floor(best / volume_step) * volume_step, 8)


def post_json(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    request = urllib.request.Request(
        f"{WORKER_BASE_URL}{path}",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {BRIDGE_TOKEN}"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:  # pragma: no cover - runtime path
        body = error.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {error.code}: {body}") from error


if __name__ == "__main__":  # pragma: no cover - runtime script
    try:
        raise SystemExit(main())
    finally:
        mt5.shutdown()
